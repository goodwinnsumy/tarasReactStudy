export const ADD_POST = "ADD_POST";

export const addPostCreator = (v) => {
    return {
        type: ADD_POST,
        payload: v
    }
}